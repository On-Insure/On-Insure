/*jslint
    this
*/
(function($) {
    "use strict"; // Start of use strict
    window.App = {};

    // makes sure the whole site is loaded and hides preloader
    $(window).on("load", function(e) {
        // will fade out the whole DIV that covers the website.
        $(".preloader").fadeOut("slow");        

        //Init WOW JS
        new WOW().init();

        // Intializing COunterup Plugin
        $('.counter').counterUp({
            delay: 10, // the delay time in ms
            time: 1000 // the speed time in ms
        });
    });

    
    // Closes the Responsive Menu on Menu Item Click
    $(".nav").on("click", function(e) {
        if($(e.target).is('a') && $(window).width() < 768) {
             $("#deskNav").addClass('hidden-xs');
        }
    });

    // jQuery for page scrolling feature applied to all pagescroll links
    // requires jQuery Easing plugin
    $('a.page-scroll').on("click", function(e) {
        var $anchor = $(this);
        $("html, body").stop().animate({
            scrollTop: ($($anchor.attr("href")).offset().top - 0)
        }, 1250, "easeInOutExpo");
        e.preventDefault();
    });

    // Offset for Main Navigation
    $("#mainMenu").affix({
        offset: {
            top: 50
        }
    });

    // Highlight the top nav as scrolling occurs
    $("body").scrollspy({
        target: ".nav-container",
        offset: 50
    });

    //  Parallax Effect background
    var parallax = document.querySelectorAll(".parallax .bg-image-placer");
    var speed = 0.5;
    $(window).on('scroll', function () {
        //reset wow animations
        if( $(window).scrollTop() <= 1) {
            $('.wow').removeClass('animated');
            $('.wow').removeAttr('style');
            new WOW().init();
        }
        //parallax background
        [].slice.call(parallax).forEach(function(el, i) {
            var windowYOffset = window.pageYOffset;
            var elBackgrounPos = "translate3d(0px," + (windowYOffset * speed) + "px, 0px)";
            //el.style.backgroundPosition = elBackgrounPos;
            el.style.transform = elBackgrounPos;
        });
    });

    

    //image to Background image Settings
    $(".bg-image-placer").each(function() {
        var image = $(this).children("img").attr("src");
        $(this).css("background", 'url("' + image + '")').css("background-position", "initial").css("opacity", "1");
    })

    // Screenshot slider intialization
    $('.mobi-screenshot-slider').owlCarousel({
        loop: true,
        nav: true,
        margin: 5,
        dots: false,
        autoplay: true,
        autoplayTimeout: 4000,
        smartSpeed: 500,
        center: true,
        navText: ['<i class="material-icons">keyboard_arrow_left</i>', '<i class="material-icons">keyboard_arrow_right</i>'],
        responsive: {
            0: {
                items: 1,
            },
            600: {
                items: 3
            },
            1200: {
                items: 5
            }
        }
    });
    // Carousel Intialization
    $(".testimonial-slider").owlCarousel({
        loop: true,
        nav: false,
        margin: 0,
        autoplay: true,
        autoplayTimeout: 4000,
        smartSpeed: 500,
        responsive: {
            0: {
                items: 1,
            },
            600: {
                items: 1
            },
            1200: {
                items: 1
            }
        }
    })

    // Data-toggle for responsive Menu
    $("[data-toggle-class]").each(function() {
        var element = $(this);
        var classData = element.attr("data-toggle-class").split("|");
        $(classData).each(function() {
            var item = element,
                classArray = [],
                classArray = this.split(";"),
                toggleClass = "",
                toggleItem = "";
            if (classArray.length === 2) {
                toggleItem = classArray[0];
                toggleClass = classArray[1];
                $(item).on("click", function() {
                    if (!item.hasClass("toggled-class")) {
                        item.toggleClass("toggled-class");
                    } else {
                        item.removeClass("toggled-class");
                    }
                    $(toggleItem).toggleClass(toggleClass);
                    return false;
                });
            }
        });
    });

    //Parallax banner
    App.parallaxs = (function() {
        return {
            obj: null
        }
    })();
    if (document.getElementById("main_slide_3") != undefined) {
        App.parallaxs.obj = new Parallax(document.getElementById("main_slide_3"));
    }

})(jQuery); // End of use strict